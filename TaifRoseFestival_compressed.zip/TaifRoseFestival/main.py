import os
import sys

# أضف المسار الحالي إلى نظام المسارات
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)

from app import app  # noqa: F401

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
