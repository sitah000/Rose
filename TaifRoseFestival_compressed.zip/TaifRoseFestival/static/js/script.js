document.addEventListener('DOMContentLoaded', function() {
    // Image Slider functionality
    const slides = document.querySelectorAll('.slider img');
    if (slides.length > 0) {
        let currentSlide = 0;
        
        // Set first slide as active
        slides[0].classList.add('active');
        
        // Function to change slide
        function changeSlide() {
            // Remove active class from current slide
            slides[currentSlide].classList.remove('active');
            
            // Calculate next slide index
            currentSlide = (currentSlide + 1) % slides.length;
            
            // Add active class to next slide
            slides[currentSlide].classList.add('active');
        }
        
        // Change slide every 5 seconds
        setInterval(changeSlide, 5000);
    }
    
    // Add active class to current nav link
    const currentLocation = window.location.pathname;
    const navLinks = document.querySelectorAll('nav a');
    
    navLinks.forEach(link => {
        // Get the link's href attribute and extract the path
        const linkPath = new URL(link.href).pathname;
        
        // Check if this link's path matches the current page or if it's the home page
        if (currentLocation === linkPath || 
            (currentLocation === '/' && linkPath === '/') ||
            (currentLocation !== '/' && linkPath !== '/' && currentLocation.includes(linkPath))) {
            link.classList.add('active');
        }
    });
    
    // مربعات النص تظهر دائمًا دون تأثيرات
    const infoBoxes = document.querySelectorAll('.info-box');
    
    // إزالة أي تأثيرات وجعلها مرئية دائمًا
    infoBoxes.forEach(box => {
        box.style.opacity = '1';
    });
});
